<template>
  <div id="Login">
     <div class="container-scroller">
    <div class="container-fluid page-body-wrapper full-page-wrapper">
      <div class="main-panel">
        <div class="content-wrapper d-flex align-items-center auth no-p-t no-p-b">
          <div class="row w-100">
            <div class="col-lg-4 mx-auto">
              <div class="auth-form-light text-center p-5">
                <div class="brand-logo">
                  <img src="../../../public/images/logo1-mini.png" alt="logo">
                </div>
                <h4>-- Espace de Connexion --</h4>
                <h6 class="font-weight-light">Connectez-vous à votre interface.</h6>
                <form class="pt-3">
                  <div class="form-group">
                    <input 
                      type="email" 
                      class="form-control form-control-lg" 
                      id="exampleInputEmail1" 
                      placeholder="Login"
                    >
                  </div>
                  <div class="form-group">
                    <input 
                      type="password" 
                      class="form-control form-control-lg" 
                      id="exampleInputPassword1" 
                      placeholder="Password"
                    >
                  </div>
                  <div class="mt-3">
                    <a 
                      class="btn btn-block btn-primary btn-lg font-weight-medium auth-form-btn" 
                      href=""
                      v-on:click.prevent="apiCheck()"
                    >
                    CONNEXION
                    </a>
                  </div>
                  <div class="my-2 d-flex justify-content-between align-items-center">
                    <div class="form-check">
                      <label class="form-check-label text-muted">
                        <input 
                          type="checkbox" 
                          class="form-check-input"
                        >
                        Mémoriser
                      </label>
                    </div>
                    <a 
                      href="#" 
                      class="auth-link text-black"
                    >
                    Mot de passe oublié ?
                    </a>
                  </div>
                </form>

                <div class="align-center justify-center row fill-height">
                  <a href="http://www.fyle-group.com/">
                    <img 
                      class="logo-bottom" 
                      src="../../../public/images/fyle-group.jpg" 
                      alt="logo"
                    >
                  </a>
                </div>

              </div>
            </div>
          </div>
        </div>

      </div>
      <!-- content-wrapper ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  </div>
</template>

<style scoped>
@import url(./style.css);
</style>

<script>
import apiConfig from '../../plugins/apiConfig';
export default {
  data () {
    return {}
  },
  methods : {
    // JQUERY METHODS
    JqueryFonctions () {
      $(function() {
        var body = $('body');
        var contentWrapper = $('.content-wrapper');
        var scroller = $('.container-scroller');
        var footer = $('.footer');
        var sidebar = $('.sidebar');

        //Add active class to nav-link based on url dynamically
        //Active class can be hard coded directly in html file also as required

        function addActiveClass(element) {
          if (current === "") {
            //for root url
            if (element.attr('href').indexOf("index.html") !== -1) {
              element.parents('.nav-item').last().addClass('active');
              if (element.parents('.sub-menu').length) {
                element.closest('.collapse').addClass('show');
                element.addClass('active');
              }
            }
          } else {
            //for other url
            if (element.attr('href').indexOf(current) !== -1) {
              element.parents('.nav-item').last().addClass('active');
              if (element.parents('.sub-menu').length) {
                element.closest('.collapse').addClass('show');
                element.addClass('active');
              }
              if (element.parents('.submenu-item').length) {
                element.addClass('active');
              }
            }
          }
        }

        var current = location.pathname.split("/").slice(-1)[0].replace(/^\/|\/$/g, '');
        $('.nav li a', sidebar).each(function() {
          var $this = $(this);
          addActiveClass($this);
        })

        $('.horizontal-menu .nav li a').each(function() {
          var $this = $(this);
          addActiveClass($this);
        })

        //Close other submenu in sidebar on opening any

        sidebar.on('show.bs.collapse', '.collapse', function() {
          sidebar.find('.collapse.show').collapse('hide');
        });


        //Change sidebar and content-wrapper height
        applyStyles();

        function applyStyles() {
          //Applying perfect scrollbar
          if (!body.hasClass("rtl")) {
            if ($('.settings-panel .tab-content .tab-pane.scroll-wrapper').length) {
              const settingsPanelScroll = new PerfectScrollbar('.settings-panel .tab-content .tab-pane.scroll-wrapper');
            }
            if ($('.chats').length) {
              const chatsScroll = new PerfectScrollbar('.chats');
            }
            if (body.hasClass("sidebar-fixed")) {
              if($('#sidebar').length) {
                var fixedSidebarScroll = new PerfectScrollbar('#sidebar .nav');
              }
            }
          }
        }

        $('[data-toggle="minimize"]').on("click", function() {
          if ((body.hasClass('sidebar-toggle-display')) || (body.hasClass('sidebar-absolute'))) {
            body.toggleClass('sidebar-hidden');
          } else {
            body.toggleClass('sidebar-icon-only');
          }
        });

        //checkbox and radios
        $(".form-check label,.form-radio label").append('<i class="input-helper"></i>');

        //Horizontal menu in mobile
        $('[data-toggle="horizontal-menu-toggle"]').on("click", function() {
          $(".horizontal-menu .bottom-navbar").toggleClass("header-toggled");
        });
        // Horizontal menu navigation in mobile menu on click
        var navItemClicked = $('.horizontal-menu .page-navigation >.nav-item');
        navItemClicked.on("click", function(event) {
          if(window.matchMedia('(max-width: 991px)').matches) {
            if(!($(this).hasClass('show-submenu'))) {
              navItemClicked.removeClass('show-submenu');
            }
            $(this).toggleClass('show-submenu');
          }        
        })

        $(window).scroll(function() {
          if(window.matchMedia('(min-width: 992px)').matches) {
            var header = $('.horizontal-menu');
            if ($(window).scrollTop() >= 70) {
              $(header).addClass('fixed-on-scroll');
            } else {
              $(header).removeClass('fixed-on-scroll');
            }
          }
        });
      });
    },
    // API CHECK
    apiCheck () {
      let data = 'test'
      this.axios
          .get(apiConfig.baseURL + 'test/api/' + data, {
            headers: apiConfig.headers
          }).then(response => {
            console.log(response)
              this.$router.push("/dashboard");
          }).catch(error => {
            console.log(error)
          })
    }
  },
  mounted() {
    // Au chargement du composant déclenche l'ensemble des scripts du template
    this.JqueryFonctions()
  },
}
</script>
