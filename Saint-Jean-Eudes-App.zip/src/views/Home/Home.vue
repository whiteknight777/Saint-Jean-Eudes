<template>
      <div class="wraper">
        <TopBar></TopBar>
        <!-- partial -->
        <div class="container-fluid page-body-wrapper">
          <div class="main-panel">
            <Content></Content>
            <Footer></Footer>
          </div>
          <!-- main-panel ends -->
        </div>

    </div>
</template>

<style scoped>
@import url(./style.css);
</style>

<script>
import TopBar from '../../components/TopBar/TopBar'
import Content from './Content'
import Footer from '../../components/Footer/Footer'

export default {
  components: {
    TopBar,
    Content,
    Footer
  },
  methods: {
    
  }
}
</script>
