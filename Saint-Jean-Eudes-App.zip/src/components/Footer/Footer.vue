<template>
  <div id="Footer">
    <!--==========================================-->
    <!-- FOOTER -->
    <!--==========================================-->
    <!-- partial:partials/_footer.html -->
    <footer class="footer">
        <div class="container w-100 clearfix">
        <span class="text-muted d-block text-center text-sm-left d-sm-inline-block">Copyright © 2018 </span>
        <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center"><a href="http://www.fyle-group.com/" target="_blank">Fyle Group</a>. All rights reserved.</span>
        </div>
    </footer>

    <!--  -->
  </div>
</template>

<style scoped>
  @import url(./style.css);
</style>

<script>
export default {
  data () {
    return {}
  },
  methods: {}
}
</script>
